package edu.neu.coe.info6205.hashtable;

public class HashTable {

    int size;

    public HashTable(int capacity) {
    }

    public void put(Object key, Object value) {
    }

    public Object getValue(Object key) {
        return null;
    }

    // This is only for testing and should be made private
    public boolean check(int bits, int length) {
        return false;
    }

    public void show() {

    }

}
