/*
 * Copyright (c) 2017. Phasmid Software
 */

package edu.neu.coe.info6205;

//import edu.neu.coe.info6205.equable.BaseComparableEquable;


//public class ComparableTuple<T extends Comparable<T>> extends BaseComparableEquable<T> implements Comparable<ComparableTuple<T>> {
//
//    private final int x;
//    private final double y;
//
//    public ComparableTuple(int x, double y) {
//        this.x = x;
//        this.y = y;
//    }
//
//    @Override
//    public String toString() {
//        return "Tuple(" + x + ", " + y + ")";
//    }
//
//
//    @Override
//    public Equable getEquable() {
//        Collection<Object> elements = new ArrayList();
//        elements.add(new Integer(x));
//        elements.add(new Double(y));
//        return new Equable(elements);
//    }
//}
