/*
 * Copyright (c) 2017. Phasmid Software
 */

//package edu.neu.coe.info6205.equable;
//
//public abstract class BaseComparableEquable<T extends Comparable<T>> extends BaseEquable implements Comparable<ComparableEquable<T>> {
//    @Override
//    public int compareTo(ComparableEquable<T> o) {
//        Equable equable = (Equable) o;
//            return getEquable().compareTo(equable.getEquable());
//        }
//
//    }
//}
