/*
 * Copyright (c) 2017. Phasmid Software
 */

package edu.neu.coe.info6205;

//public class ComparableTupleTest {
//
//    /**
//     * Test method for Tuple
//     */
//    @Test
//    public void testComparableTuple() {
//        ComparableTuple tuple1 = new ComparableTuple(1, Math.PI);
//        ComparableTuple tuple2 = new ComparableTuple(2, Math.E);
//        assertEquals(1, tuple1.compareTo(tuple2));
//    }
//
//}
