# INFO6205 [![CircleCI](https://circleci.com/gh/rchillyard/INFO6205.svg?style=svg)](https://circleci.com/gh/rchillyard/INFO6205)
This is the class repository for Program Structure and Algorithms
